import cv2 as cv
import numpy as np
import os.path


# rootdir = r'D:\用户目录\我的图片\From Yun\背景图\背景图'  # 指明被遍历的文件夹
rootdir = r'D:\shujuji\CSU-Crack-master\label_png_black'

for parent, dirnames, filenames in os.walk(rootdir):  # 遍历图片
    for filename in filenames:
        print('parent is :' + parent)
        print('filename is :' + filename)
        currentPath = os.path.join(parent, filename)
        print('the full name of the file is :' + currentPath)

        image=cv.imread(currentPath)
        # print(image)
        #result = np.zeros(image.shape, dtype=np.float32)
        # cv2.normalize(image, result, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
        result = image / 255.0  # 与cv2.normalize效果一样

        '''
        src = cv.imread(currentPath)
        cv.namedWindow("input", cv.WINDOW_AUTOSIZE)
        cv.imshow("input", src)
        gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)

        # 转换为浮点数类型数组
        gray = np.float32(gray)
        print(gray)

        # scale and shift by NORM_MINMAX
        dst = np.zeros(gray.shape, dtype=np.float32)
        cv.normalize(gray, dst=dst, alpha=0, beta=1.0, norm_type=cv.NORM_MINMAX)

        cv.imshow("NORM_MINMAX", np.uint8(dst * 255))

        # scale and shift by NORM_INF
        dst = np.zeros(gray.shape, dtype=np.float32)
        cv.normalize(gray, dst=dst, alpha=1.0, beta=0, norm_type=cv.NORM_INF)
        print(dst)
        cv.imshow("NORM_INF", np.uint8(dst * 255))

        # scale and shift by NORM_L1
        dst = np.zeros(gray.shape, dtype=np.float32)
        cv.normalize(gray, dst=dst, alpha=1.0, beta=0, norm_type=cv.NORM_L1)
        print(dst)
        cv.imshow("NORM_L1", np.uint8(dst * 10000000))

        # scale and shift by NORM_L2
        dst = np.zeros(gray.shape, dtype=np.float32)
        cv.normalize(gray, dst=dst, alpha=1.0, beta=0, norm_type=cv.NORM_L2)
        print(dst)
        cv.imshow("NORM_L2", np.uint8(dst * 10000))
         '''
        # newname=r"D:\用户目录\我的图片\From Yun\背景图\背景图反转"+'\\'+filename+"(1).jpg"
        newname = r"D:\shujuji\CSU-Crack-master\label_png_black_nomalization" + '\\' + filename   # 重新命名
        cv.imwrite(newname,  result)#保存结束


