
import cv2
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import xlwt
import openpyxl.workbook
from openpyxl import Workbook
import math

img = cv2.imread('C:/Users/heyingchun/Desktop/main1/001.png')
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

low_hsv = np.array([0, 0, 221])
high_hsv = np.array([180, 30, 255])
mask = cv2.inRange(hsv, lowerb=low_hsv, upperb=high_hsv)

#print(len(mask))
#print(len(mask[0]))

list_y = []
list_x = []
list_r = []
list_g = []
list_b = []
list_nx = []
list_ny = []
list_nz = []


'''
########################################################################################################################

for i in range(len(mask)):
    print(mask[i])
    xmax = []
    for j in range(len(mask[i])):
        if mask[i][j] == 0:
           # print(mask[i][j],j,i)
            print(img[i][j],j,i)
            list_x.append(j)
            list_y.append(len(mask)-i)
            list_b.append(img[i][j][0])
            list_g.append(img[i][j][1])
            list_r.append(img[i][j][2])

plt.plot(list_x, list_y, 'o', color='g')
plt.show()

dat=np.array([list_x,list_y,list_r,list_g,list_b],dtype=np.float)
'''
#########################################################################################################################
for i in range(len(mask)):
    print(mask[i])
    xmax = []
    for j in range(len(mask[i])):
        if mask[i][j] == 0:
           # print(mask[i][j],j,i)
            print(img[i][j],j,i)
            list_x.append(len(mask)-j)
            list_y.append(i)
            list_b.append(img[i][j][0])
            list_g.append(img[i][j][1])
            list_r.append(img[i][j][2])
zhou=(max(list_x)+min(list_x))/2
R=(max(list_x)-min(list_x))/3.1415926535

for i in range(len(list_x)):
    list_nx.append(R*math.sin((list_x[i]-zhou)/R)+R)
    list_ny.append(R*math.cos((list_x[i]-zhou)/R))
for j in range(len(list_y)):
    list_nz.append(list_y[j])


dat=np.array([list_nx,list_nz,list_ny,list_r,list_g,list_b],dtype=np.float)


#########################################################################################################################

data=pd.DataFrame(dat.T)
#data=dat.T

writer = pd.ExcelWriter('001top.xlsx')
#header参数表示列的名称，index表示行的标签
data.to_excel(writer, 'sheet_1', float_format='%.2f', header=False, index=False)
writer.save()
