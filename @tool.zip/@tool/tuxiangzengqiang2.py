import numpy as np
import cv2
img = cv2.imread("C:/Users/heyingchun/Desktop/example/100145.png", 0)
# 图像归一化
fi = img / 255.0
# 伽马变换
gamma = 0.5
out = np.power(fi, gamma)
cv2.imshow("out", out)
cv2.waitKey()