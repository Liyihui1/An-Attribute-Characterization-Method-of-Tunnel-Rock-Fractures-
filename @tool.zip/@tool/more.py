import cv2
import numpy as np

path = '/home/zhangwei/workfiles/deeplearning/dogVScat/data/cat_1.jpg'
img = cv2.imread(path)

#-----> 翻转（flip）<--------------#
# 用numpy实现
flip_21 = np.fliplr(img) # 水平翻转
flip_22 = np.transpose	# 转置





