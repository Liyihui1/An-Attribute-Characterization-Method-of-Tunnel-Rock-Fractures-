import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image
import matplotlib as mpl

###定义腐蚀运算函数
def img_erode(bin_im, kernel, center_coo):
    kernel_w = kernel.shape[0]
    kernel_h = kernel.shape[1]
    if kernel[center_coo[0], center_coo[1]] == 0:
        raise ValueError("指定原点不在结构元素内！")
    erode_img = np.zeros(shape=bin_im.shape)
    for i in range(center_coo[0], bin_im.shape[0]-kernel_w+center_coo[0]+1):
        for j in range(center_coo[1], bin_im.shape[1]-kernel_h+center_coo[1]+1):
            a = bin_im[i-center_coo[0]:i-center_coo[0]+kernel_w,
                j-center_coo[1]:j-center_coo[1]+kernel_h]  # 找到每次迭代中对应的目标图像小矩阵
            if np.sum(a * kernel) == np.sum(kernel):  # 判定是否“完全重合”
                erode_img[i, j] = 1
    return erode_img

###定义膨胀运算函数
def img_dilate(bin_im, kernel, center_coo):
    kernel_w = kernel.shape[0]
    kernel_h = kernel.shape[1]
    if kernel[center_coo[0], center_coo[1]] == 0:
        raise ValueError("指定原点不在结构元素内！")
    dilate_img = np.zeros(shape=bin_im.shape)
    for i in range(center_coo[0], bin_im.shape[0] - kernel_w + center_coo[0] + 1):
        for j in range(center_coo[1], bin_im.shape[1] - kernel_h + center_coo[1] + 1):
            a = bin_im[i - center_coo[0]:i - center_coo[0] + kernel_w,
                j - center_coo[1]:j - center_coo[1] + kernel_h]
            dilate_img[i, j] = np.max(a * kernel)  # 若“有重合”，则点乘后最大值为0
    return dilate_img

###黑白互换
def rgb2gray(rgb_img):
    gray = cv2.cvtColor(rgb_img, cv2.COLOR_BGR2GRAY)
    return gray

###灰度图转二值图（阈值法）
def im_binary(gray_image, t=180):#t为阈值，可以进行修改
    binary_image = np.zeros(shape=(gray_image.shape[0], gray_image.shape[1]), dtype=np.uint8)
    for i in range(gray_image.shape[0]):
        for j in range(gray_image.shape[1]):
            if gray_image[i][j] > t:
                binary_image[i][j] = 1
            else:
                binary_image[i][j] = 0
    return binary_image

###开运算（先腐蚀再膨胀）
def img_open(bin_im, erope_k, erope_c_c, dilate_k, dilate_c_c):
    open_img = img_erode(bin_im, erope_k, erope_c_c)
    open_img = img_dilate(open_img, dilate_k, dilate_c_c)
    return open_img

###闭运算（先膨胀再腐蚀）
def img_close(bin_im, erope_k, erope_c_c, dilate_k, dilate_c_c):
    close_img = img_dilate(bin_im, dilate_k, dilate_c_c)
    close_img = img_erode(close_img, erope_k, erope_c_c)
    return close_img

####主函数调用
if __name__ == "__main__":
    img = cv2.imread(r"C:/Users/heyingchun/Desktop/lyh1/20040.png" ) # 此处可以是指定路径的rgb图像
    gray_img = rgb2gray(img)
    print("原始二值图像")
    bin_img = im_binary(gray_img)
    kernel1 = np.ones(shape=(3, 3))  # 此处声明结构元素，可以自定义为非规则形状
    center1 = [1, 1]  # 此处声明结构元素原点，这里取其正中心像素点
    kernel2 = np.ones(shape=(5, 5))  # 同上
    center2 = [2, 2]  # 同上
    print("原始二值图像腐蚀")
    erode_im = img_erode(bin_img, kernel2, center2)
    print("原始二值图像膨胀")
    dilate_im = img_dilate(bin_img, kernel2, center2)
    print("原始二值图像开运算")
    open_im = img_open(bin_img, kernel1, center1, kernel1, center1)
    print("原始二值图像闭运算")
    close_im = img_close(bin_img, kernel1, center1, kernel1, center1)




    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_hd.jpg',gray_img*255)
    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_ez.jpg',bin_img*255)
    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_pz.jpg',erode_im*255)
    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_fs.jpg',dilate_im*255)
    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_op.jpg',open_im*255)
    cv2.imwrite('C:/Users/heyingchun/Desktop/lyh1/20040_dn_cl.jpg',close_im*255)



'''
plt.savefig('C:/Users/heyingchun/Desktop/example/100145_dn_hd.jpg')
plt.imshow(gray_img, cmap="gray")

plt.savefig('C:/Users/heyingchun/Desktop/example/100145_dn_ez.jpg')
plt.imshow(bin_img, cmap="gray")

plt.savefig('C:/Users/heyingchun/Desktop/example/100145_dn_pz.jpg')
plt.imshow(erode_im, cmap="gray")
plt.savefig('C:/Users/heyingchun/Desktop/example/100145_dn_fs.jpg')
plt.imshow(dilate_im, cmap="gray")

plt.imshow(open_im, cmap="gray")

plt.imshow(close_im, cmap="gray")

'''



