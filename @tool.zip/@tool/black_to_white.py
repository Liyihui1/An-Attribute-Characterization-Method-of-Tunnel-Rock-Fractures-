import os.path
import cv2

# rootdir = r'D:\用户目录\我的图片\From Yun\背景图\背景图'  # 指明被遍历的文件夹
rootdir = r'C:\Users\heyingchun\Desktop\0515dn_b_100'

for parent, dirnames, filenames in os.walk(rootdir):  # 遍历图片
    for filename in filenames:
        print('parent is :' + parent)
        print('filename is :' + filename)
        currentPath = os.path.join(parent, filename)
        print('the full name of the file is :' + currentPath)

        im=cv2.imread(currentPath)
        #彩色图像转为灰度图像（3通道变为1通道）
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        #最大图像灰度值减去原图像，即可得到反转的图像
        out=255-gray
        # newname=r"D:\用户目录\我的图片\From Yun\背景图\背景图反转"+'\\'+filename+"(1).jpg"
        newname = r"C:\Users\heyingchun\Desktop\0515dn_w_100" + '\\' + filename   # 重新命名
        cv2.imwrite(newname,out,) #保存结束
# im = Image.open(r'C:\Users\Administrator\Desktop\新建文件夹 (2)\1.jpg')
# out = im.transpose(Image.FLIP_LEFT_RIGHT)
# out.save(r'C:\Users\Administrator\Desktop\新建文件夹 (2)\test2.jpg')