import cv2
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import xlwt
import openpyxl.workbook
from openpyxl import Workbook

img = cv2.imread('C:/Users/heyingchun/Desktop/example/100145_dn_xh.png')
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

low_hsv = np.array([0, 0, 221])
high_hsv = np.array([180, 30, 255])
mask = cv2.inRange(hsv, lowerb=low_hsv, upperb=high_hsv)

#print(len(mask))
#print(len(mask[0]))

list_y = []
list_x = []

for i in range(len(mask)):
    print(mask[i])
    xmax = []
    for j in range(len(mask[i])):
        if mask[i][j] == 0:
            print(mask[i][j],j,i)
            list_x.append(j)
            list_y.append(len(mask)-i)

plt.plot(list_x, list_y, 'o', color='r')
plt.show()

dat=np.array([list_x,list_y],dtype=np.int)


#######################################################################################################################
data=pd.DataFrame(dat.T)
#data=dat.T

writer = pd.ExcelWriter('1.xlsx')
#header参数表示列的名称，index表示行的标签
data.to_excel(writer, 'sheet_1', float_format='%.2f', header=False, index=False)
writer.save()

#####################################聚类##############################################################################
# -*- coding:utf-8 -*-
# -*- author：zzZ_CMing
# -*- 2018/04/10；15:38
# -*- python3.5

import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
import matplotlib.colors

# 创建Figure
fig = plt.figure()
# 用来正常显示中文标签
matplotlib.rcParams['font.sans-serif'] = [u'SimHei']
# 用来正常显示负号
matplotlib.rcParams['axes.unicode_minus'] = False

X1, y1 = datasets.make_circles(n_samples=5000, factor=.6,
                                      noise=.05)
X2, y2 = datasets.make_blobs(n_samples=1000, n_features=2,
                             centers=[[1.2,1.2]], cluster_std=[[.1]],random_state=9)

# 原始点的分布
ax1 = fig.add_subplot(131)
#X = data[np.random.choice(data.shape[0],size=10000,replace=False),:]
X=data

plt.scatter(X[:, 0], X[:, 1], marker='o',s=0.1)
plt.title(u'原始数据分布')
plt.sca(ax1)


# K-means聚类
from sklearn.cluster import KMeans
ax2 = fig.add_subplot(132)
y_pred = KMeans(n_clusters=20, random_state=9).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'K-means聚类')
plt.sca(ax2)
# DBSCAN聚类

from sklearn.cluster import DBSCAN
ax3 = fig.add_subplot(231)
y_pred = DBSCAN(eps =1, min_samples =1).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_1')
plt.sca(ax3)


from sklearn.cluster import DBSCAN
ax4 = fig.add_subplot(232)
y_pred = DBSCAN(eps =1, min_samples =2).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_2')
plt.sca(ax4)


from sklearn.cluster import DBSCAN
ax5 = fig.add_subplot(233)
y_pred = DBSCAN(eps =1, min_samples =3).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_3')
plt.sca(ax5)


from sklearn.cluster import DBSCAN
ax6 = fig.add_subplot(234)
y_pred = DBSCAN(eps =1, min_samples =4).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_4')
plt.sca(ax6)


from sklearn.cluster import DBSCAN
ax7 = fig.add_subplot(235)
y_pred = DBSCAN(eps =1, min_samples =5).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_5')
plt.sca(ax7)


from sklearn.cluster import DBSCAN
ax8 = fig.add_subplot(236)
y_pred = DBSCAN(eps =1, min_samples =6).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1_6')
plt.sca(ax8)

from sklearn.cluster import DBSCAN
ax5 = fig.add_subplot(111)
y_pred = DBSCAN(eps =1.5, min_samples =3).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred,s=0.2,cmap='tab20')
plt.title(u'DBSCAN聚类_1.5_3')
plt.sca(ax5)
plt.show()
