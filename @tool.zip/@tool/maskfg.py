import cv2
import numpy as np

img = cv2.imread("E:/gongong/xinjiang/0515/001.png")
mask = cv2.imread("E:/gongong/xinjiang/0515dn_zq_600/dn_zq_001.jpg", 0)  # Read grayscale image

# Resize img to match the size of mask using nearest-neighbor interpolation
height, width = mask.shape
img = cv2.resize(img, (width, height), interpolation=cv2.INTER_NEAREST)

b, g, r = cv2.split(img)

# -----------------1. Get a transparent foreground image-----------
dstt = np.zeros((4, height, width), dtype=img.dtype)

dstt[0][0:height, 0:width] = b
dstt[1][0:height, 0:width] = g
dstt[2][0:height, 0:width] = r
dstt[3][0:height, 0:width] = mask
cv2.imwrite("fore.png", cv2.merge(dstt))

# -----------------2. Composite with a new background image-----------
bg = np.zeros((3, height, width), dtype=img.dtype)  # Generate a background image
bg[0][0:height, 0:width] = 255  # Background image in blue
# bg[1][0:height, 0:width] = 255  # Green background image
# bg[2][0:height, 0:width] = 255  # Red background image

dstt = np.zeros((3, height, width), dtype=img.dtype)

for i in range(3):
    dstt[i][:, :] = bg[i][:, :] * (255.0 - mask) / 255
    dstt[i][:, :] += np.array(img[:, :, i] * (mask / 255), dtype=np.uint8)
cv2.imwrite("0311001.png", cv2.merge(dstt))
