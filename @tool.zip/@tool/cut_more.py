import os
from PIL import Image
b = 0
dir = 'C:/Users/heyingchun/Desktop/tunnel_cut'            #目录文件夹名称
files = os.listdir(dir)
files.sort()
while(b < 1):#1是因为目录文件夹下只有一个子文件夹，要是对多个文件夹图像批量处理，只要改成相应数目即可
    #这里采用的是判断文件名的方式进行处理
    ss = './1/' + str(files[b]) + '/' #训练图片
    pics = os.listdir(ss) #得到1文件下所指文件内的图片
    i = 0
    for each_bmp in pics:  # 遍历，进行批量转换
        first_name, second_name = os.path.splitext(each_bmp)
        each_bmp = os.path.join(ss, each_bmp)
        image = Image.open(each_bmp)
        img = image.convert('RGB')
        w = img.size[0]               #获取图片宽度
        h = img.size[1]               #获取图片高度
        img_1 = img.crop([0, 0, w / 4, h / 4])  # 获取1
        img_1.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为1.jpg
        i += 1
        img_2 = img.crop([w / 4, 0, w / 2, h / 4])  # 获得2
        img_2.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为2.jpg
        i += 1
        img_3 = img.crop([w / 2, 0, w * 3 / 4, h / 4])  # 获取3
        img_3.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为3.jpg
        i += 1
        img_4 = img.crop([w * 3 / 4, 0, w, h / 4])  # 获取4
        img_4.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_5 = img.crop([0, h / 4, w / 4, h / 2])
        img_5.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_6 = img.crop([w / 4, h / 4, w / 2, h / 2])
        img_6.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_7 = img.crop([w / 2, h / 4, w * 3 / 4, h / 2])
        img_7.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_8 = img.crop([w * 3 / 4, h / 4, w, h / 2])
        img_8.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_9 = img.crop([0, h / 2, w / 4, h * 3 / 4])
        img_9.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_10 = img.crop([w / 4, h / 2, w / 2, h * 3 / 4])
        img_10.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_11 = img.crop([w / 2, h / 2, w * 3 / 4, h * 3 / 4])
        img_11.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_12 = img.crop([w * 3 / 4, h / 2, w, h * 3 / 4])
        img_12.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_13 = img.crop([0, h * 3 / 4, w / 4, h])
        img_13.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_14 = img.crop([w / 4, h * 3 / 4, w / 2, h])
        img_14.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_15 = img.crop([w / 2, h * 3 / 4, w * 3 / 4, h])
        img_15.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1
        img_16 = img.crop([w * 3 / 4, h * 3 / 4, w, h])
        img_16.save(ss + str(i) + '.jpg')  # 保存在本地图片命名为4.jpg
        i += 1

    b += 1