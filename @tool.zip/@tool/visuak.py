import tensorflow
from tensorflow.keras import layers, models, Input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dense, Flatten, Dropout,BatchNormalization,Activation
from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
model = ResNet50(weights='D:/yuanma/tool/model_weights.h5',
                 include_top=False,)
#model.load_weights('resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5')
model.load_weights('D:/yuanma/tool/model_weights.h5',by_name=True)
model.summary()
########################################################################################################################

import numpy as np
img_path = 'img/1.jpg'
img = image.load_img(img_path, target_size=(400,500))
img_tensor = image.img_to_array(img)
img_tensor = np.expand_dims(img_tensor, axis=0)
# Remember that the model was trained on inputs
# that were preprocessed in the following way:
img_tensor /= 255.

# Its shape is (1, 500, 333, 3)
#print(img_tensor.shape)

########################################################################################################################
import matplotlib.pyplot as plt
#plt.imshow(img_tensor[0])
#plt.show()

########################################################################################################################
from keras import models
# 提取2-50层的特征
layer_outputs = [layer.output for layer in model.layers[2:51]]
# Creates a model that will return these outputs, given the model input:
activation_model = models.Model(inputs=model.input, outputs=layer_outputs)
########################################################################################################################
# This will return a list of 5 Numpy arrays:
# one array per layer activation
activations = activation_model.predict(img_tensor)
########################################################################################################################
first_layer_activation = activations[0]#层数！！！！！！！！！！！！！！！
print(first_layer_activation.shape)

########################################################################################################################
# This will return a list of 5 Numpy arrays:
# one array per layer activation
activations = activation_model.predict(img_tensor)
########################################################################################################################

plt.matshow(first_layer_activation[0, :, :,1], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_1",dpi=500)
plt.matshow(first_layer_activation[0, :, :,2], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_2",dpi=500)
plt.matshow(first_layer_activation[0, :, :,3], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_3",dpi=500)
plt.matshow(first_layer_activation[0, :, :,4], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_4",dpi=500)
plt.matshow(first_layer_activation[0, :, :,5], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_5",dpi=500)
plt.matshow(first_layer_activation[0, :, :,6], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_6",dpi=500)
plt.matshow(first_layer_activation[0, :, :,7], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_7",dpi=500)
plt.matshow(first_layer_activation[0, :, :,8], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_8",dpi=500)
plt.matshow(first_layer_activation[0, :, :,9], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_9",dpi=500)
plt.matshow(first_layer_activation[0, :, :,10], cmap='viridis')#通道数！！！！！！！
plt.savefig ("1_0_10",dpi=500)
#plt.show()
