from PIL import Image
import os.path
import cv2


# rootdir = r'D:\用户目录\我的图片\From Yun\背景图\背景图'  # 指明被遍历的文件夹
rootdir = r'C:\Users\heyingchun\Desktop\output'

for parent, dirnames, filenames in os.walk(rootdir):  # 遍历图片
    for filename in filenames:
        print('parent is :' + parent)
        print('filename is :' + filename)
        currentPath = os.path.join(parent, filename)
        print('the full name of the file is :' + currentPath)
        image = Image.open(currentPath)
        #image = cv2.imread(currentPath)
        img = image.convert('RGB')  # 转换成RGB三通道格式
        w = img.size[0]  # 获取图片宽度
        h = img.size[1]  # 获取图片高度
        img_1 = img.crop([0, 0, w / 4, h / 4])  # 获取1
        img_1.save( '1'+'_' +filename)
        img_2 = img.crop([w / 4, 0, w / 2, h / 4])  # 获得2
        img_2.save('2' + '_' + filename)
        img_3 = img.crop([w / 2, 0, w * 3 / 4, h / 4])  # 获取3
        img_3.save('3' + '_' + filename)
        img_4 = img.crop([w * 3 / 4, 0, w, h / 4])  # 获取4
        img_4.save('4' + '_' + filename)
        img_5 = img.crop([0, h / 4, w / 4, h / 2])
        img_5.save( '5'+'_' +filename)
        img_6 = img.crop([w / 4, h / 4, w / 2, h / 2])
        img_6.save('6' + '_' + filename)
        img_7 = img.crop([w / 2, h / 4, w * 3 / 4, h / 2])
        img_7.save('7' + '_' + filename)
        img_8 = img.crop([w * 3 / 4, h / 4, w, h / 2])
        img_8.save( '8'+'_' +filename)
        img_9 = img.crop([0, h / 2, w / 4, h * 3 / 4])
        img_9.save( '9'+'_' +filename)
        img_10 = img.crop([w / 4, h / 2, w / 2, h * 3 / 4])
        img_10.save( '10'+'_' +filename)
        img_11 = img.crop([w / 2, h / 2, w * 3 / 4, h * 3 / 4])
        img_11.save( '11'+'_' +filename)
        img_12 = img.crop([w * 3 / 4, h / 2, w, h * 3 / 4])
        img_12.save( '12'+'_' +filename)
        img_13 = img.crop([0, h * 3 / 4, w / 4, h])
        img_13.save( '13'+'_' +filename)
        img_14 = img.crop([w/4, h * 3 / 4, w /2, h])
        img_14.save( '14'+'_' +filename)
        img_15 = img.crop([w / 2, h * 3 / 4, w * 3 / 4, h])
        img_15.save('15' + '_' + filename)
        img_16 = img.crop([w * 3 / 4, h * 3 / 4, w, h])
        img_16.save( '16'+'_' +filename)
