"""
Author:XiaoMa
date:2021/10/25
"""
import cv2
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'SimHei'  # matplotlib 绘图库正常使用中文黑体

# 读取图像信息
img0 = cv2.imread('C:/Users/heyingchun/Desktop/example/100145.png')
img1 = cv2.resize(img0, dsize=None, fx=0.5, fy=0.5)
h, w = img1.shape[:2]
print(h, w)
img2 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
cv2.namedWindow("W0")
cv2.imshow("W0", img1)
cv2.waitKey(delay=0)
#绘制直方图
'''
hist0 = cv2.calcHist([img2], [0], None, [256], [0, 255])
plt.plot(hist0, label = "灰度图直方图", linestyle = "--", color = 'g')
plt.legend()   #增加图例
plt.savefig("E:\From Zhihu\For the desk\cveight0.jpg")  #保存直方图
plt.show()
'''
img3 = cv2.equalizeHist(img2) #直方图均衡化
cv2.namedWindow("W1")
cv2.imshow("W1", img3)
cv2.waitKey(delay = 0)
#绘制均衡化后的直方图
'''
#绘制直方图
hist0 = cv2.calcHist([img2], [0], None, [256], [0, 255])
hist1 = cv2.calcHist([img3], [0], None, [256], [0, 255])
plt.subplot(2,1,1)
plt.plot(hist0, label = "灰度图直方图", linestyle = "--", color = 'g')
plt.legend()
plt.subplot(2,1,2)
plt.plot(hist1, label = "均衡化后的直方图", linestyle = "--", color = 'r')
plt.legend()
plt.savefig("E:\From Zhihu\For the desk\cveight0.jpg")
plt.show()
'''
#对图像进行局部直方图均衡化
clahe = cv2.createCLAHE (clipLimit = 2.0, tileGridSize=(10, 10))  #对图像进行分割，10*10
img4 = clahe.apply(img2)                                          #进行直方图均衡化
cv2.namedWindow("W2")
cv2.imshow("W2", img4)
cv2.waitKey(delay = 0)