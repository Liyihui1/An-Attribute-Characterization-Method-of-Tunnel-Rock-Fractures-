import math

import cv2
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.pyplot import show
########################################################################################################################
from numpy import ndarray
from skimage.filters._gabor import gabor_kernel

fingerprint = cv2.imread('C:/Users/heyingchun/Desktop/100145_230204/101_1.tif ', cv2.IMREAD_GRAYSCALE)

########################################################################################################################
# Calculate the local gradient (using Sobel filters)
gx, gy = cv2.Sobel(fingerprint, cv2.CV_32F, 1, 0), cv2.Sobel(fingerprint, cv2.CV_32F, 0, 1)
#gx,gy= cv2.Sobel(fingerprint,cv2.CV_64F,1,0),cv2.Sobel(fingerprint,cv2.CV_64F,0,1),
#gx,gy = cv2.convertScaleAbs(gx), cv2.convertScaleAbs(gy),
cv2.imshow('gx',gx)
cv2.waitKey(0)
cv2.destroyAllWindows()
# Calculate the local gradient (using Sobel filters)
#gx, gy = cv2.Sobel(fingerprint, cv2.CV_32F,1, 0), cv2.Sobel(fingerprint, cv2.CV_32F, 0, 1)
cv2.imshow('gy',gy)
cv2.waitKey(0)
cv2.destroyAllWindows()
########################################################################################################################
# Calculate the magnitude of the gradient for each pixel
gx2, gy2 = gx**2, gy**2
gm = np.sqrt(gx2 + gy2)
#gm =  cv2.addWeighted(gx,0.5,gy,0.5,0)
cv2.imshow('gm',gm)
cv2.waitKey(0)
cv2.destroyAllWindows()

########################################################################################################################
# Integral over a square window
sum_gm = cv2.boxFilter(gm, -1, (25, 25), normalize = False)
#sum_gm=gm
cv2.imshow('Integral of the gradient magnitude',sum_gm)
cv2.waitKey(0)
cv2.destroyAllWindows()
########################################################################################################################
# Use a simple threshold for segmenting the fingerprint pattern
thr = sum_gm.max() * 0.1
mask = cv2.threshold(sum_gm, thr, 255, cv2.THRESH_BINARY)[1].astype(np.uint8)
cv2.imshow('mask',mask)
cv2.waitKey(0)
cv2.destroyAllWindows()

########################################################################################################################
W = (23, 23)#我们定义一个23x23的窗口
gxx = cv2.boxFilter(gx2, -1, W, normalize = False)# 在给定的滑动窗口大小下，对每个窗口内的像素值进行快速相加求和
gyy = cv2.boxFilter(gy2, -1, W, normalize = False)
gxy = cv2.boxFilter(gx * gy, -1, W, normalize = False) # gx * gy
gxx_gyy = gxx - gyy
gxy2 = 2 * gxy

orientations = (cv2.phase(gxx_gyy, -gxy2) + np.pi) / 2 # '-' to adjust for y axis direction phase函数计算方向场
sum_gxx_gyy = gxx + gyy
strengths = np.divide(cv2.sqrt((gxx_gyy**2 + gxy2**2)), sum_gxx_gyy, out=np.zeros_like(gxx), where=sum_gxx_gyy!=0)#  计算置信度，也就是计算在W 中有多少梯度有同样的方向，自然数量越多，计算的结果越可靠
cv2.imshow('orientations',orientations)
cv2.waitKey(0)
cv2.destroyAllWindows()
########################################################################################################################
region = fingerprint[20:180,160:260]
plt.imshow(region)
#show(region)
########################################################################################################################
# before computing the x-signature, the region is smoothed to reduce noise
smoothed = cv2.blur(region, (5,5), -1)
xs = np.sum(smoothed, 1) # the x-signature of the region
#print(xs)
########################################################################################################################
x = np.arange(region.shape[0])
f, axarr = plt.subplots(1,2, sharey = True)
axarr[0].imshow(region,cmap='gray')
axarr[1].plot(xs, x)
axarr[1].set_ylim(region.shape[0]-1,0)
plt.show()
# Find the indices of the x-signature local maxima
local_maxima = np.nonzero(np.r_[False, xs[1:] > xs[:-1]] & np.r_[xs[:-1] >= xs[1:], False])[0]
x = np.arange(region.shape[0])
plt.plot(x, xs)
plt.xticks(local_maxima)
plt.grid(True, axis='x')
plt.show()
# Calculate all the distances between consecutive peaks
distances = local_maxima[1:] - local_maxima[:-1]
print(distances)
# [10 10 11 10  9  8  8]
# Estimate the ridge line period as the average of the above distances
ridge_period = np.average(distances)
ridge_period=round(ridge_period)
print(ridge_period)# 9.428571428571429
#########################################################################################################################
# Create the filter bank

# Create the filter bank
import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
# 显示图像的函数
import matplotlib.pyplot as plt
def display_imgs(imgs,num_cols=5):
    num=len(imgs)
    num_rows=math.ceil(num/num_cols)
    fig=plt.figure(figsize=(num_cols*5,num_rows*5))
    for i in range(num):
        ax=fig.add_subplot(num_rows,num_cols,i+1)
        ax.imshow(imgs[i],cmap ='gray')
    plt.show()

# 傅里叶变换
def my_fft(img):
    f = np.fft.fft2(img)
#     print(f.shape,f.size,f.dtype)
    fshift = np.fft.fftshift(f).astype(np.float32)
#     fshift=fshift.real
    fshift=np.sqrt(np.power(fshift.imag,2)+np.power(fshift.real,2)) #获得幅值图像
#     print(fshift.shape,fshift.size,fshift.dtype)
    fshift=(fshift-np.min(fshift))/(np.max(fshift)-np.min(fshift)) #最大最小归一化
    return fshift
# help(np.complex128)
or_count = 8
wh=10
bzc=1
yxb=0.5
kgb=1
xwpy=0
#gabor_bank = [gabor_kernel(ridge_period, o) for o in np.arange(0, np.pi, np.pi/or_count)]

kernel1=cv2.getGaborKernel((wh,wh), bzc, np.degrees(0), yxb,kgb, xwpy, cv2.CV_32F)
kernel2=cv2.getGaborKernel((wh,wh), bzc, np.degrees(22.5),yxb, kgb, xwpy, cv2.CV_32F)
kernel3=cv2.getGaborKernel((wh,wh),bzc, np.degrees(45), yxb, kgb, xwpy, cv2.CV_32F)
kernel4=cv2.getGaborKernel((wh,wh), bzc, np.degrees(67.5),yxb,kgb, xwpy, cv2.CV_32F)
kernel5=cv2.getGaborKernel((wh,wh), bzc, np.degrees(90), yxb, kgb, xwpy, cv2.CV_32F)
kernel6=cv2.getGaborKernel((wh,wh), bzc, np.degrees(112.5), yxb, kgb, xwpy, cv2.CV_32F)
kernel7=cv2.getGaborKernel((wh,wh), bzc, np.degrees(135), yxb,kgb,xwpy, cv2.CV_32F)
kernel8=cv2.getGaborKernel((wh,wh), bzc , np.degrees(157.5), yxb, kgb , xwpy  , cv2.CV_32F)
imgs=[kernel1,kernel2,kernel3,kernel4,kernel5,kernel6,kernel7,kernel8,my_fft(kernel1), my_fft(kernel2), my_fft(kernel3), my_fft(kernel4),my_fft(kernel5), my_fft(kernel6), my_fft(kernel7), my_fft(kernel8)]
display_imgs(imgs,num_cols=8)
gabor_bank=[kernel1,kernel2,kernel3,kernel4,kernel5,kernel6,kernel7,kernel8]


# Filter the whole image with each filter
# Note that the negative image is actually used, to have white ridges on a black background as a result
nf = 255-fingerprint
#all_filtered= np.array([cv2.filter2D(nf, cv2.CV_32F, f) for f in gabor_bank])
all_filtered= np.array([cv2.filter2D(nf, cv2.CV_32F, f) for f in gabor_bank])

y_coords, x_coords = np.indices(fingerprint.shape)
# For each pixel, find the index of the closest orientation in the gabor bank
orientation_idx = np.round(((orientations % np.pi) / np.pi) * or_count).astype(np.int32) % or_count
# Take the corresponding convolution result for each pixel, to assemble the final result
filtered = all_filtered[orientation_idx, y_coords, x_coords]
# Convert to gray scale and apply the mask
enhanced = mask & np.clip(filtered, 0, 255).astype(np.uint8)
# Binarization
_, ridge_lines = cv.threshold(enhanced, 100, 255, cv.THRESH_BINARY)# enhanced 是增强之后的图像
plt.imshow(ridge_lines,cmap ='gray')
plt.show()


# Thinning
kernel = np.ones((5, 5), np.uint8)
ridge_lines = cv.erode(ridge_lines, kernel, iterations=2)
ridge_lines = cv.dilate(ridge_lines, kernel, iterations=1)
ridge_lines = cv.erode(ridge_lines, kernel, iterations=2 )
# 4.细化处理
skeleton = cv.ximgproc.thinning(ridge_lines, thinningType = cv.ximgproc.THINNING_GUOHALL)
plt.imshow(skeleton,cmap ='gray')
plt.show()
#cv.imwrite("C:/Users/heyingchun/Desktop/example/100145_dn_zq.png",enhanced)