import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn import preprocessing
from sklearn.cluster import DBSCAN

fpath = "D:/yuanma/tool/dnzq001.xlsx"#打开神秘的文件
data = pd.read_excel(fpath,names=["hzb","zzb","red","green","blue"])#给每个列取个名字，经度纬度用拼音代替
#print(data['date'])

X1=data['hzb']
X2=data['zzb']
X=np.vstack((X1,X2)).T
X = pd.DataFrame(X)
y_pred = DBSCAN(eps=1.5, min_samples=6).fit_predict(X)
plt.scatter(X[0], X[1], c=y_pred,s=0.2,cmap='tab20')
plt.show()
print(y_pred)

import openpyxl as op

def write():
    num_list = y_pred

    bg = op.load_workbook(r"D:/yuanma/tool/dnzq001.xlsx")  # 应先将excel文件放入到工作目录下
    sheet = bg["sheet_1"]  # “Sheet1”表示将数据写入到excel文件的sheet1下
    for i in range(2, len(num_list) + 1):
        sheet.cell(i, 6, num_list[i - 2])  # sheet.cell(1,1,num_list[0])表示将num_list列表的第0个数据1写入到excel表格的第一行第一列
    bg.save("D:/yuanma/tool/dnzq001.xlsx")  # 对文件进行保存


write()
