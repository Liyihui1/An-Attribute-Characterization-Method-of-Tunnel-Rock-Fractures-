from collections import Counter
import numpy as np
import cv2
import cv2
import numpy as np
import matplotlib.pyplot as plt

img_name0 = 'C:/Users/heyingchun/Desktop/example/100145.png'
img0 = cv2.imread(img_name0)

plt.imshow(img0)
plt.show()

def hist_binarization(img):
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hist = img_gray.flatten()
    plt.subplot(121)
    plt.hist(hist, 256)
    cnt_hist = Counter(hist)
    most_commons = cnt_hist.most_common(2)
    # get the grey values of bimodal histogram
    begin, end = most_commons[0][0], most_commons[1][0]
    if begin > end:
        begin, end = end, begin
    print(f'{begin}: {end}')

    cnt = np.iinfo(np.int16).max
    threshold = 0
    for i in range(begin, end+1):
        if cnt_hist[i] < cnt:
            cnt = cnt_hist[i]
            threshold = i
    print(f'{threshold}: {cnt}')
    img_gray[img_gray>threshold] = 255
    img_gray[img_gray<=threshold] = 0
    plt.subplot(122)
    plt.imshow(img_gray, cmap='gray')
    plt.show()
    return img_gray

img_gray1 = hist_binarization(img0)
def otsu(img):
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = img_gray.shape[:2]
    pixel = h * w
    threshold_k = 0
    max_var = .0

    for k in range(255):
        c1 = img_gray[img_gray <= k]

        p1 = len(c1) / pixel
        if p1 == 0:
            continue
        elif p1 == 1:
            break

        MG = np.sum(img_gray) / pixel

        m = np.sum(c1) / pixel

        d = (MG*p1 - m) ** 2 / (p1 * (1 - p1))
        if d > max_var:
            max_var = d
            threshold_k = k

    img_gray[img_gray <= threshold_k] = 0
    img_gray[img_gray > threshold_k] = 255

    print(f"{threshold_k}")
    plt.imshow(img_gray, cmap='gray')
    plt.show()
    return img_gray

img_gray2 = otsu(img0)
