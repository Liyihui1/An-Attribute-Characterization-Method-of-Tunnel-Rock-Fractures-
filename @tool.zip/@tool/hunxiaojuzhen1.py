"""
    画混淆矩阵，需要(真实标签，预测标签，标签列表）
    y_test, y_pred, display_labels

    混淆矩阵用:      sklearn库中的confusion_matrix
    混淆矩阵画图用：  sklearn库中的ConfusionMatrixDisplay
                    matplotlib库中的pyplot

    这里用iris数据集做例子，SVM做分类器。
"""

import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.datasets import load_iris
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

# 设置西文字体为新罗马字体
from matplotlib import rcParams
config = {
     #"mathtext.fontset":'stix',  # 设置字体类型
     "font.family":'Times New Roman',
     "font.size": 18,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


labels = ['ZT', 'KZ', 'CZ', 'SL', 'ST']
y_test = np.loadtxt('C:/Users/heyingchun/Desktop/shuju/predict/resnet50/true.txt')
y_pred = np.loadtxt('C:/Users/heyingchun/Desktop/shuju/predict/resnet50/pre.txt')
print("y_test: ", y_test)
print("y_pred: ", y_pred)

# 得到混淆矩阵(confusion matrix,简称cm)
# confusion_matrix 需要的参数：y_true(真实标签),y_pred(预测标签)
cm = confusion_matrix(y_true=y_test, y_pred=y_pred)
# 得到混淆矩阵(confusion matrix,简称cm)
#confusion_matrix 需要的参数：y_true(真实标签),y_pred(预测标签),normalize(归一化,'true', 'pred', 'all')
#cm = confusion_matrix(y_true=y_test, y_pred=y_pred, normalize='true')
#cm=np.around(cm,decimals=4)

# 打印混淆矩阵
print("Confusion Matrix: ")
print(cm)

# 画出混淆矩阵
# ConfusionMatrixDisplay 需要的参数: confusion_matrix(混淆矩阵), display_labels(标签名称列表)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(cmap = ('binary'))
plt.show()
########################################################################################################################





