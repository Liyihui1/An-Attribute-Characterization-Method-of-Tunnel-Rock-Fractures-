import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize
plt.rc('font', family='Times New Roman')
#plt.rcParams['font.size'] = 16

# 读取数据
file_path = 'C:/Users/heyingchun/Desktop\property_predict/intergrity-points.txt'  # 替换为你的文件路径
data = np.loadtxt(file_path)

# 分离坐标和属性值
coordinates = data[:, :3]
property_values = data[:, 3]

# 设置绘图
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 绘制散点图，颜色根据属性值设置
sc = ax.scatter(coordinates[:, 0], coordinates[:, 1], coordinates[:, 2], c=property_values, cmap='jet')

# 添加颜色条
cbar = plt.colorbar(sc,shrink=0.8)
cbar.set_ticks(np.arange(property_values.min(), property_values.max() + 1, 1))
cbar.set_label('Property Value')

# 设置坐标轴
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# 设置坐标轴比例相等
ax.set_box_aspect([np.ptp(coord) for coord in coordinates.T])
# 保存图像
plt.savefig('3d_scatter_plot.png', dpi=300, bbox_inches='tight')  # 修改文件名和格式
# 显示图形
plt.show()
