import cv2
import numpy as np
import matplotlib.pyplot as plt
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize
plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 16
# 读取二值图像
binary_image = cv2.imread('dn_zq.jpg', cv2.IMREAD_GRAYSCALE)

# 定义区间划分
intervals = [0, 15, 50, 150, 250, 500, float('inf')]
'''
# 新的测线长度为600
line_length = 600

# 保留边界300像素
margin = 300

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 11
step_y = (binary_image.shape[0] - 2 * margin) // 9

# 新的测线长度为600
line_length = 750

# 保留边界200像素
margin = 375

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 9
step_y = (binary_image.shape[0] - 2 * margin) // 7
'''
# 新的测线长度为1000
line_length = 1000

# 保留边界300像素
margin = 500

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 7
step_y = (binary_image.shape[0] - 2 * margin) // 6

# 权重
weights = [1, 3, 10, 30, 50, 100]

# 初始化每个测点处的计算结果字典
results = {}

# 遍历每个测点
for i in range(margin, binary_image.shape[0] - margin, step_y):
    for j in range(margin, binary_image.shape[1] - margin, step_x):
        # 在测点处以测点为中心横向布置一条长度为600的测线
        line = binary_image[i, j:j + line_length]

        # 找到黑色像素的位置
        black_pixels = np.where(line == 0)[0]

        # 添加测线两端的端点
        endpoints = [0, line_length]

        # 如果存在黑色像素，添加黑色像素的位置作为端点
        if len(black_pixels) > 0:
            endpoints.extend(black_pixels)

        # 将端点排序
        endpoints = sorted(endpoints)

        # 计算每个子线段的长度
        segment_lengths = np.diff(endpoints)

        # 统计在不同区间内的子线长度之和
        interval_sums = [np.sum(segment_lengths[(segment_lengths >= intervals[i]) & (segment_lengths <= intervals[i+1])]) for i in range(len(intervals)-1)]

        # 计算属性值
        attribute_value = np.dot(interval_sums, weights) / 1000

        # 将结果存入字典
        results[(i, j)] = attribute_value

# 提取测点和属性值
points = list(results.keys())
values = list(results.values())

# 获取图像的形状
image_shape = binary_image.shape

# 调整横纵坐标，确保与图像形状一致
adjusted_points = [(point[1], point[0]) for point in points]
'''
#D=1.2
adjusted_points_hidden = adjusted_points[4:8] + adjusted_points[15:21] + adjusted_points[26:34] + adjusted_points[37:47] + adjusted_points[49:59] + adjusted_points[60:]
values_hidden = values[4:8] + values[15:21] + values[26:34] + values[37:47] + values[49:59] + values[60:]

#D=1.5
adjusted_points_hidden = adjusted_points[3:7]+adjusted_points[12:18]+adjusted_points[21:29]+adjusted_points[30:]
# 提取对应的属性值
values_hidden = values[3:7]+values[12:18]+values[21:29]+values[30:]
'''
#D=2.0
adjusted_points_hidden = adjusted_points[2:6]+adjusted_points[9:15]+adjusted_points[16:]
values_hidden = values[2:6]+values[9:15]+values[16:]

# 绘制散点图
plt.scatter(*zip(*adjusted_points_hidden), c=values_hidden, cmap='jet_r', vmin=0, vmax=100, s=30, marker='o', edgecolors='none')
plt.colorbar(label='Intergrity Value',shrink=0.8)
#添加标题
plt.title('Horizontal Intergrity (D=2.0m)',fontsize=20)

# 绘制在原图上
plt.imshow(binary_image, cmap='gray', alpha=0.2)
plt.axis('off')
#保存图像
plt.savefig('Horizontal Intergrity (D=2.0m).png', bbox_inches='tight')
# 显示图像
plt.show()
