import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# 创建一个图形
fig = plt.figure()

# 添加3D坐标轴
ax = fig.add_subplot(111, projection='3d')

# 长方体的尺寸
length = 3
width = 1
height = 1

# 长方体的坐标
x = np.array([0, 0, length, length, 0, 0, length, length])
y = np.array([0, width, width, 0, 0, width, width, 0])
z = np.array([0, 0, 0, 0, height, height, height, height])

# 绘制实心长方体
ax.plot_surface([x[:4]], [y[:4]], [z[:4]], color='b', alpha=0.6)
ax.plot_surface([x[4:]], [y[4:]], [z[4:]], color='b', alpha=0.6)

# 设置坐标轴标签
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# 设置坐标轴比例一致
ax.set_box_aspect([length, width, height])

# 显示图形
plt.show()
  