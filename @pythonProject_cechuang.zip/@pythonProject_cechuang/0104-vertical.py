import cv2
import numpy as np
import matplotlib.pyplot as plt

plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 16

binary_image = cv2.imread('dn_zq.jpg', cv2.IMREAD_GRAYSCALE)

intervals = [0, 15, 50, 150, 250, 500, float('inf')]

'''
# 新的测线长度为600
line_length = 600

# 保留边界300像素
margin = 300

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 11
step_y = (binary_image.shape[0] - 2 * margin) // 9

# 新的测线长度为750
line_length = 750

# 保留边界375像素
margin = 375

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 9
step_y = (binary_image.shape[0] - 2 * margin) // 7
'''
# 新的测线长度为1000
line_length = 1000

# 保留边界500像素
margin = 500

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 7
step_y = (binary_image.shape[0] - 2 * margin) // 6

weights = [1, 3, 10, 30, 50, 100]

results = {}

for i in range(margin, binary_image.shape[0] - margin, step_y):
    for j in range(margin, binary_image.shape[1] - margin, step_x):
        line = binary_image[i:i + line_length, j]  # 获取纵向测线数据

        black_pixels = np.where(line == 0)[0]
        endpoints = [0, line_length]

        if len(black_pixels) > 0:
            endpoints.extend(black_pixels)

        endpoints = sorted(endpoints)
        segment_lengths = np.diff(endpoints)
        interval_sums = [np.sum(segment_lengths[(segment_lengths >= intervals[i]) & (segment_lengths <= intervals[i + 1])]) for i in range(len(intervals) - 1)]
        attribute_value = np.dot(interval_sums, weights) / line_length

        results[(i, j)] = attribute_value

points = list(results.keys())
values = list(results.values())
image_shape = binary_image.shape
adjusted_points = [(point[1], point[0]) for point in points]

'''
#D=1.2
adjusted_points_hidden = adjusted_points[4:8] + adjusted_points[15:21] + adjusted_points[26:34] + adjusted_points[37:47] + adjusted_points[49:59] + adjusted_points[60:]
values_hidden = values[4:8] + values[15:21] + values[26:34] + values[37:47] + values[49:59] + values[60:]

#D=1.5
adjusted_points_hidden = adjusted_points[3:7]+adjusted_points[12:18]+adjusted_points[21:29]+adjusted_points[30:]
# 提取对应的属性值
values_hidden = values[3:7]+values[12:18]+values[21:29]+values[30:]
'''
#D=2.0
adjusted_points_hidden = adjusted_points[2:6]+adjusted_points[9:15]+adjusted_points[16:]
values_hidden = values[2:6]+values[9:15]+values[16:]

plt.scatter(*zip(*adjusted_points_hidden), c=values_hidden, cmap='jet_r', vmin=0, vmax=100, s=30, marker='o', edgecolors='none')
plt.colorbar(label='Intergrity Value', shrink=0.8)
plt.title('Vertical Intergrity (D=2.0m)', fontsize=20)

plt.imshow(binary_image, cmap='gray', alpha=0.2)
plt.axis('off')
plt.savefig('Vertical Intergrity (D=2.0m).png', bbox_inches='tight')
plt.show()
