import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize

plt.rc('font', family='Times New Roman')

def sliding_window(image, window_size, step_size):
    features = []
    centers = []  # 存储测窗中心坐标

    # 获取图像尺寸
    height, width = image.shape

    # 遍历图像，以滑动窗口方式提取特征
    for y in range(0, height - window_size[1] + 1, step_size[1]):
        for x in range(0, width - window_size[0] + 1, step_size[0]):
            # 定义滑动窗口
            window = image[y:y + window_size[1], x:x + window_size[0]]

            # 计算测窗中心坐标
            center_x = x + window_size[0] // 2
            center_y = y + window_size[1] // 2
            centers.append((center_x, center_y))

            # 统计黑色像素的比例
            black_pixel_ratio = np.sum(window == 0) / window.size
            features.append(black_pixel_ratio)

    return features, centers


def visualize_features_as_scatter(features, centers, window_size, original_image, output_image_name, alpha=0.5):
    # 设置字体
    prop = font_manager.FontProperties()

    # 创建图形对象
    plt.figure()

    # 先绘制色度条
    norm = Normalize(vmin=0, vmax=0.1)
    plt.imshow([[0, 0.1]], cmap='jet', aspect='auto', extent=[-1, 0, -1, 0], alpha=0)

    # 绘制原始图像，并设置透明度
    plt.imshow(original_image, cmap='gray', alpha=alpha)

    # 绘制离散点图，禁用坐标轴刻度
    plt.scatter(*zip(*centers), c=features, cmap='jet', s=30, marker='o', edgecolors='none', norm=norm)
    plt.title('D=2m w=0.8m h=0.6m', fontproperties=prop, fontsize=18)  # 调整标题字体大小
    plt.xlabel('X Coordinate', fontproperties=prop, fontsize=16)  # 调整横坐标标签字体大小
    plt.ylabel('Y Coordinate', fontproperties=prop, fontsize=16)  # 调整纵坐标标签字体大小
    plt.xticks([])  # 禁用横坐标刻度
    plt.yticks([])  # 禁用纵坐标刻度

    # 绘制colorbar，设置colorbar的字体大小和高度
    cbar = plt.colorbar(label='Intergrity Value', shrink=0.8)
    cbar.ax.tick_params(labelsize=16)  # 调整colorbar刻度字体大小
    cbar.ax.set_ylabel('Intergrity Value', rotation=90, fontsize=16)  # 调整colorbar标签字体大小
    cbar.set_ticks([0, 0.02, 0.04, 0.06, 0.08, 0.1])
    cbar.set_ticklabels(['0', '0.02', '0.04', '0.06', '0.08', '0.10'])
    # 保存图像
    plt.savefig(output_image_name, bbox_inches='tight')  # 使用bbox_inches='tight'确保保存整个图像
    plt.close()  # 关闭图形

if __name__ == "__main__":
    # 读取二值图像
    image_path = "dn_zq.jpg"
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # 用户手动输入窗口大小和步长
    window_size = (int(input("Enter window width (D): ")), int(input("Enter window height (D): ")))
    step_size = (int(input("Enter horizontal step size (w): ")), int(input("Enter vertical step size (h): ")))

    # 提取特征和测窗中心坐标
    features, centers = sliding_window(image, window_size, step_size)

    # 设置原图透明度为0.5，并可视化特征值为彩色离散点图并保存在原图像上
    output_image_name = "FG D=2m w=0.8m h=0.6m.png"
    visualize_features_as_scatter(features, centers, window_size, image, output_image_name, alpha=0.2)
