import cv2
import numpy as np
import matplotlib.pyplot as plt
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize
plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 16
# 读取二值图像
binary_image = cv2.imread('dn_zq.jpg', cv2.IMREAD_GRAYSCALE)

# 定义区间划分
intervals = [0, 15, 50, 150, 250, 500, float('inf')]

# 新的测线长度为600
line_length = 750

# 保留边界200像素
margin = 200

# 计算内部均匀分布的步长，使得测点均匀分布在图像上
step_x = (binary_image.shape[1] - 2 * margin) // 11
step_y = (binary_image.shape[0] - 2 * margin) // 9

# 权重
weights = [1, 3, 10, 30, 50, 100]

# 初始化每个测点处的计算结果字典
results = {}

# 遍历每个测点
for i in range(margin, binary_image.shape[0] - margin, step_y):
    for j in range(margin, binary_image.shape[1] - margin, step_x):
        # 在测点处以测点为中心横向布置一条长度为600的测线
        line = binary_image[i, j:j + line_length]

        # 找到黑色像素的位置
        black_pixels = np.where(line == 0)[0]

        # 添加测线两端的端点
        endpoints = [0, line_length]

        # 如果存在黑色像素，添加黑色像素的位置作为端点
        if len(black_pixels) > 0:
            endpoints.extend(black_pixels)

        # 将端点排序
        endpoints = sorted(endpoints)

        # 计算每个子线段的长度
        segment_lengths = np.diff(endpoints)

        # 统计在不同区间内的子线长度之和
        interval_sums = [np.sum(segment_lengths[(segment_lengths >= intervals[i]) & (segment_lengths <= intervals[i+1])]) for i in range(len(intervals)-1)]

        # 计算属性值
        attribute_value = np.dot(interval_sums, weights)/750

        # 将结果存入字典
        results[(i, j)] = attribute_value

# 提取测点和属性值
points = list(results.keys())
values = list(results.values())

# 获取图像的形状
image_shape = binary_image.shape

# 调整横纵坐标，确保与图像形状一致
adjusted_points = [(point[1], point[0]) for point in points]

# 绘制散点图
plt.scatter(*zip(*adjusted_points), c=values, cmap='jet',vmin=0,vmax=100, s=30, marker='o', edgecolors='none')
plt.colorbar(label='Intergrity Value',shrink=0.8)
#添加标题
plt.title('Horizontal Intergrity (D=1.5m)',fontsize=20)

# 绘制在原图上
plt.imshow(binary_image, cmap='gray', alpha=0.5)
plt.axis('off')
#保存图像
plt.savefig('Horizontal Intergrity (D=1.2m).png', bbox_inches='tight')
# 显示图像
plt.show()
